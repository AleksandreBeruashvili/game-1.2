package com.example.game1

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity(),View.OnClickListener {

    private lateinit var button1: Button
    private lateinit var button2: Button
    private lateinit var button3: Button
    private lateinit var button4: Button
    private lateinit var button5: Button
    private lateinit var button6: Button
    private lateinit var button7: Button
    private lateinit var button8: Button
    private lateinit var button9: Button
    private lateinit var resultbutton: Button

    private var activePlayer = 1
    private var fPlayer = ArrayList<Int>()
    private var sPlayer = ArrayList<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        init()
    }

    private fun init() {
        button1 = findViewById(R.id.button1)
        button2 = findViewById(R.id.button2)
        button3 = findViewById(R.id.button3)
        button4 = findViewById(R.id.button4)
        button5 = findViewById(R.id.button5)
        button6 = findViewById(R.id.button6)
        button7 = findViewById(R.id.button7)
        button8 = findViewById(R.id.button8)
        button9 = findViewById(R.id.button9)
        resultbutton = findViewById(R.id.resultbutton)
        button1.setOnClickListener(this)
        button2.setOnClickListener(this)
        button3.setOnClickListener(this)
        button4.setOnClickListener(this)
        button5.setOnClickListener(this)
        button6.setOnClickListener(this)
        button7.setOnClickListener(this)
        button8.setOnClickListener(this)
        button9.setOnClickListener(this)
    }
    override fun onClick(clickedView: View?) {
        if (clickedView is Button) {
            var buttonNumber = 0
            when (clickedView.id) {
                R.id.button1 -> buttonNumber = 1
                R.id.button2 -> buttonNumber = 2
                R.id.button3 -> buttonNumber = 3
                R.id.button4 -> buttonNumber = 4
                R.id.button5 -> buttonNumber = 5
                R.id.button6 -> buttonNumber = 6
                R.id.button7 -> buttonNumber = 7
                R.id.button8 -> buttonNumber = 8
                R.id.button9 -> buttonNumber = 9
            }
            if (buttonNumber != 0) {
                playGame(clickedView, buttonNumber)
            }
        }
    }
    private fun playGame(clickedView: Button, buttonNumber: Int) {
        if (activePlayer == 1) {
            clickedView.text = "X"
            clickedView.setBackgroundColor(Color.GRAY)
            activePlayer = 2
            fPlayer.add(buttonNumber)

        } else if (activePlayer == 2) {
            clickedView.text = "0"
            clickedView.setBackgroundColor(Color.BLUE)
            activePlayer = 1
            sPlayer.add(buttonNumber)
        }
        clickedView.isEnabled = false
        check()
    }
    private fun check() {
        var wPlayer = 0
        if (fPlayer.contains(1) && fPlayer.contains(2) && fPlayer.contains(3)) {
            wPlayer = 1
        }
        if (sPlayer.contains(4) && sPlayer.contains(5) && sPlayer.contains(6)) {
            wPlayer = 2
        }
        if (fPlayer.contains(7) && fPlayer.contains(8) && fPlayer.contains(9)) {
            wPlayer = 1
        }
        if (sPlayer.contains(1) && sPlayer.contains(4) && sPlayer.contains(7)) {
            wPlayer = 2
        }
        if (fPlayer.contains(2) && fPlayer.contains(5) && fPlayer.contains(8)) {
            wPlayer = 1
        }
        if (sPlayer.contains(3) && sPlayer.contains(6) && sPlayer.contains(9)) {
            wPlayer = 2
        }
        if (fPlayer.contains(1) && fPlayer.contains(5) && fPlayer.contains(9)) {
            wPlayer = 1
        }
        if (sPlayer.contains(3) && sPlayer.contains(5) && sPlayer.contains(7)) {
            wPlayer = 2
        }
        if (wPlayer == 1) {
            Toast.makeText(applicationContext, " გაიმარჯვა პირველმა " , Toast.LENGTH_LONG).show()
        }
        if (wPlayer == 2) {
            Toast.makeText(applicationContext, " გაიმარჯვა მეორემ ", Toast.LENGTH_LONG).show()
        }
        if (fPlayer.size + sPlayer.size == 9 && wPlayer == 0) {
            Toast.makeText(applicationContext, " გაიმარჯვა მეგობრობამ ", Toast.LENGTH_LONG).show()
        }
    }
}
